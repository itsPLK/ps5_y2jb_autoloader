(async () => {
    
    await log("Hello from remote JS!");
    send_notification("Hello from remote JS!");
    
})()